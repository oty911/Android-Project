package com.example.buanamekar.FilePemasukan;

public class ClassPemasukan {

    private String tanggal;
    private String tanggalBulan;
    private String tanggalTahun;
    private String waktu;
    private String nominal;
    private String namaBarang;
    private String jumlahBarang;
    private String nomorPelanggan;
    private String spinnerNamaPelanggan;
    private String spinnerKategori;

    public ClassPemasukan() {
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getTanggalBulan() {
        return tanggalBulan;
    }

    public void setTanggalBulan(String tanggalBulan) {
        this.tanggalBulan = tanggalBulan;
    }

    public String getTanggalTahun() {
        return tanggalTahun;
    }

    public void setTanggalTahun(String tanggalTahun) {
        this.tanggalTahun = tanggalTahun;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public String getNominal() {
        return nominal;
    }

    public void setNominal(String nominal) {
        this.nominal = nominal;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    public String getJumlahBarang() {
        return jumlahBarang;
    }

    public void setJumlahBarang(String jumlahBarang) {
        this.jumlahBarang = jumlahBarang;
    }

    public String getNomorPelanggan() {
        return nomorPelanggan;
    }

    public void setNomorPelanggan(String nomorPelanggan) {
        this.nomorPelanggan = nomorPelanggan;
    }

    public String getSpinnerNamaPelanggan() {
        return spinnerNamaPelanggan;
    }

    public void setSpinnerNamaPelanggan(String spinnerNamaPelanggan) {
        this.spinnerNamaPelanggan = spinnerNamaPelanggan;
    }

    public String getSpinnerKategori() {
        return spinnerKategori;
    }

    public void setSpinnerKategori(String spinnerKategori) {
        this.spinnerKategori = spinnerKategori;
    }
}
