package com.example.buanamekar.Pelanggan;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.buanamekar.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DaftarPelanggan extends AppCompatActivity {

    EditText etNama,etAlamat,etTlp,etEmail;
    Button btnPelangganSimpan;

    DatabaseReference dbReferencePelanggan;
    ClassPelanggan classPelanggan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_pelanggan);

        etNama = findViewById(R.id.et_pelanggan_nama);
        etAlamat = findViewById(R.id.et_pelanggan_alamat);
        etTlp = findViewById(R.id.et_pelanggan_tlp);
        etEmail = findViewById(R.id.et_pelanggan_email);
        btnPelangganSimpan = findViewById(R.id.btn_simpan_pelanggan);

        classPelanggan = new ClassPelanggan();
        dbReferencePelanggan = FirebaseDatabase.getInstance().getReference().child("Pelanggan");
        btnPelangganSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String namaPelanggan = etNama.getText().toString().trim();
                String alamatPelanggan = etAlamat.getText().toString().trim();
                String tlpPelanggan = etTlp.getText().toString().trim();
                String emailPelanggan = etEmail.getText().toString();

                classPelanggan.setNamaPelanggan(namaPelanggan);
                classPelanggan.setAlamatPelanggan(alamatPelanggan);
                classPelanggan.setTlpPelanggan(tlpPelanggan);
                classPelanggan.setEmailPelanggan(emailPelanggan);
                dbReferencePelanggan.push().setValue(classPelanggan);
                Toast.makeText(DaftarPelanggan.this, "Data Saved", Toast.LENGTH_SHORT).show();

            }
        });

    }
}