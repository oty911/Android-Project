package com.example.buanamekar.Pelanggan;

public class ClassPelanggan {

    private String namaPelanggan;
    private String alamatPelanggan;
    private String tlpPelanggan;
    private String emailPelanggan;

    public ClassPelanggan() {
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public void setNamaPelanggan(String namaPelanggan) {
        this.namaPelanggan = namaPelanggan;
    }

    public String getAlamatPelanggan() {
        return alamatPelanggan;
    }

    public void setAlamatPelanggan(String alamatPelanggan) {
        this.alamatPelanggan = alamatPelanggan;
    }

    public String getTlpPelanggan() {
        return tlpPelanggan;
    }

    public void setTlpPelanggan(String tlpPelanggan) {
        this.tlpPelanggan = tlpPelanggan;
    }

    public String getEmailPelanggan() {
        return emailPelanggan;
    }

    public void setEmailPelanggan(String emailPelanggan) {
        this.emailPelanggan = emailPelanggan;
    }
}
