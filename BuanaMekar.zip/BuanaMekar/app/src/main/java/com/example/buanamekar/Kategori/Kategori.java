package com.example.buanamekar.Kategori;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.buanamekar.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Kategori extends AppCompatActivity {

    EditText etKategori;
    Button btnSimpanKategori;

    DatabaseReference dbReferenceKategori;
    ClassKategori classKategori;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategori);

        etKategori = findViewById(R.id.et_kategori_tambah);
        btnSimpanKategori = findViewById(R.id.btn_kategori_simpan);
        classKategori = new ClassKategori();
        dbReferenceKategori = FirebaseDatabase.getInstance().getReference().child("Kategori");

        btnSimpanKategori.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String tambahKategori = etKategori.getText().toString().trim();
                classKategori.setTambahKategori(tambahKategori);

                dbReferenceKategori.push().setValue(classKategori);
                Toast.makeText(Kategori.this, "Data Saved", Toast.LENGTH_SHORT).show();
            }
        });
    }//batasoncreate

}//batasahkir