package com.example.buanamekar.Items;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.buanamekar.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DaftarItems extends AppCompatActivity {

    Button btnSave;
    EditText etNama,etJumlah, etKeterangan;
    private Spinner spKategori;
    int maxid = 0;

    ValueEventListener valueEventListener;
    ArrayAdapter<String> arrayAdapter;
    ArrayList<String> spinnerList;

    ClassItems classItems;
    DatabaseReference dbReferenceItems;
    DatabaseReference dbReferenceKategori;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_items);

        etNama = findViewById(R.id.et_items_nama);
        etJumlah = findViewById(R.id.et_items_jumlah);
        etKeterangan = findViewById(R.id.et_items_keterangan);
        spKategori = findViewById(R.id.sp_items_kategori);
        btnSave = findViewById(R.id.btn_simpan_items);
        classItems = new ClassItems();
        dbReferenceKategori = FirebaseDatabase.getInstance().getReference().child("Kategori");
        dbReferenceItems = FirebaseDatabase.getInstance().getReference().child("Items");
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String namaBarang = etNama.getText().toString().trim();
                String jumlahBarang = etJumlah.getText().toString().trim();
                String keteranganBarang = etKeterangan.getText().toString().trim();
                final String spinKategori = spKategori.getSelectedItem().toString().trim();

                classItems.setNamaBarang(namaBarang);
                classItems.setJumlahBarang(jumlahBarang);
                classItems.setKeteranganBarang(keteranganBarang);
                classItems.setSpinner(spinKategori);
                dbReferenceItems.push().setValue(classItems).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        spinnerList.clear();
                        arrayAdapter.notifyDataSetChanged();

                    }
                });
                Toast.makeText(DaftarItems.this, "Data Saved", Toast.LENGTH_SHORT).show();
            }
        });

        spinnerList = new ArrayList<>();
        arrayAdapter = new ArrayAdapter(DaftarItems.this, android.R.layout.simple_spinner_item, spinnerList);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spKategori.setAdapter(arrayAdapter);
        ambilData();

    }//batasonCreate

    public void ambilData(){

        valueEventListener = dbReferenceKategori.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot item:snapshot.getChildren()){
                    spinnerList.add(item.getValue().toString().trim());
                }
                
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

}//batasahkir