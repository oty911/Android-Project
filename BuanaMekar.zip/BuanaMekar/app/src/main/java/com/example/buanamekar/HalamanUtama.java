package com.example.buanamekar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;

import androidx.appcompat.app.AppCompatActivity;

import com.example.buanamekar.FilePemasukan.Pemasukan;
import com.example.buanamekar.Items.DaftarItems;
import com.example.buanamekar.Kategori.Kategori;
import com.example.buanamekar.Pelanggan.DaftarPelanggan;

public class HalamanUtama extends AppCompatActivity {

    Button btn_menu,btn_profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_utama);

        btn_profile = (Button) findViewById(R.id.btn_profile);
        btn_menu = (Button) findViewById(R.id.btn_main_menu);
        btn_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popup = new PopupMenu(HalamanUtama.this, btn_menu);
                popup.getMenuInflater().inflate(R.menu.menu_popup, popup.getMenu());

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.menu_daftar_items:
                                startActivity(new Intent(getApplicationContext(), DaftarItems.class));
                                break;
                            case R.id.menu_daftar_pelanggan:
                                startActivity(new Intent(getApplicationContext(), DaftarPelanggan.class));
                                break;
                            case R.id.menu_pemasukan:
                                startActivity(new Intent(getApplicationContext(), Pemasukan.class));
                                break;
                            case R.id.menu_pengeluaran:

                                break;
                            case R.id.menu_kategori:
                                startActivity(new Intent(getApplicationContext(), Kategori.class));
                                break;
                        }
                        return true;
                    }
                });
                popup.show();
            }
        });

        btn_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });

    }//batasoncreate

}//batasahkir