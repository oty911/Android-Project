package com.example.buanamekar.Kategori;

public class ClassKategori {

    private String tambahKategori;

    public ClassKategori() {
    }

    public String getTambahKategori() {
        return tambahKategori;
    }

    public void setTambahKategori(String tambahKategori) {
        this.tambahKategori = tambahKategori;
    }
}
