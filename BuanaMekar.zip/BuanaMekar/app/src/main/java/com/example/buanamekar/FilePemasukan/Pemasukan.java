package com.example.buanamekar.FilePemasukan;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.buanamekar.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Pemasukan extends AppCompatActivity {

    EditText etPemTanggal,etPemBulan,etPemTahun,etPemWaktu,etPemNominal,etPemNama,etPemJumlah,etPemNomorPel;
    Spinner spPemasukanKategori, spPemasukanNama;
    Button btnPemasukanSimpan, btnPemasukanKeluar;
    ClassPemasukan classPemasukan;
    DatabaseReference dbReferencePemasukan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pemasukan);

        etPemTanggal = findViewById(R.id.et_pemasukan_tanggal);
        etPemBulan = findViewById(R.id.et_pemasukan_bulan);
        etPemTahun = findViewById(R.id.et_pemasukan_tahun);
        etPemWaktu = findViewById(R.id.et_pemasukan_waktu);
        etPemNominal = findViewById(R.id.et_pemasukan_nominal);
        etPemNama = findViewById(R.id.et_pemasukan_namabarang);
        etPemJumlah = findViewById(R.id.et_pemasukan_jumlah);
        etPemNomorPel = findViewById(R.id.et_pemasukan_nomor);
        spPemasukanKategori = findViewById(R.id.sp_pemasukan_kategori);
        spPemasukanNama = findViewById(R.id.sp_pemasukan_nama);

        btnPemasukanSimpan = findViewById(R.id.btn_simpan_pemasukan);
        btnPemasukanKeluar = findViewById(R.id.btn_keluar_pemasukan);

        classPemasukan = new ClassPemasukan();
        dbReferencePemasukan = FirebaseDatabase.getInstance().getReference().child("Pemasukan");
        btnPemasukanSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Tanggal = etPemTanggal.getText().toString().trim();
                String Bulan = etPemBulan.getText().toString().trim();
                String Tahun = etPemTahun.getText().toString().trim();
                String Waktu = etPemWaktu.getText().toString().trim();
                String Nominal = etPemNominal.getText().toString().trim();
                String NamaBarang = etPemNama.getText().toString().trim();
                String JumlahBarang = etPemJumlah.getText().toString().trim();
                String NomorPelanggan = etPemNomorPel.getText().toString().trim();

                String spKategoriPemasukan = spPemasukanKategori.getSelectedItem().toString();
                String spNamaPelanggan = spPemasukanNama.getSelectedItem().toString();

                classPemasukan.setTanggal(Tanggal);
                classPemasukan.setTanggalBulan(Bulan);
                classPemasukan.setTanggalTahun(Tahun);
                classPemasukan.setWaktu(Waktu);
                classPemasukan.setNominal(Nominal);
                classPemasukan.setNamaBarang(NamaBarang);
                classPemasukan.setJumlahBarang(JumlahBarang);
                classPemasukan.setNomorPelanggan(NomorPelanggan);
                classPemasukan.setSpinnerKategori(spKategoriPemasukan);
                classPemasukan.setSpinnerNamaPelanggan(spNamaPelanggan);
                dbReferencePemasukan.push().setValue(classPemasukan);
                Toast.makeText(Pemasukan.this, "Data Saved", Toast.LENGTH_SHORT).show();
            }
        });
    }//batasOnCreate


}//batasAhkir